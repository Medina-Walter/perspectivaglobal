<footer class="bg-black  py-3 mt-5">
    <p class="text-center text-white">&copy; Echo por Walter Medina</p>
</footer>
    <script src="/perspectivaglobal/js/bootstrap.bundle.min.js"></script>
</body>
</html>